package com.gymcrm.multitenancy;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

@Component
public class GymContextFilter extends OncePerRequestFilter {

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain filterChain) throws ServletException, IOException {
        Long gymId = (Long) request.getAttribute("gymId");
        try {
            if (gymId != null) {
                GymContext.set(gymId);
            }
            filterChain.doFilter(request, response);
        } finally {
            GymContext.clear();
        }
    }
}
